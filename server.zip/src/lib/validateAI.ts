import schema from "./ai-schema.json"
import Ajv from "ajv" 
import addFormats from "ajv-formats"

const ajv = new Ajv({ 
  strict: false, 
  allErrors: true 
})

addFormats(ajv)

const validate = ajv.compile(schema)

export const validateAIResult = (data: unknown) => {
  const valid = validate(data)

  if (!valid) {
    console.error("Validation errors:", validate.errors)
    throw new Error("AI response does not match schema")
  }

  return data
}